"""Loopback-only Bilibili QR login and authenticated high-resolution downloads."""
import argparse, contextlib, ctypes, hashlib, http.cookiejar, io, json, os, re, secrets
import subprocess, tempfile, threading, time, urllib.parse, urllib.request, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PORT = 8771
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0.0.0 Safari/537.36'
COOKIE_NAMES = {'SESSDATA', 'bili_jct', 'DedeUserID', 'DedeUserID__ckMd5', 'sid'}
STATE = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'CreativeHubHQ'
QR, ANALYSES, JOBS = {}, {}, {}
LOCK = threading.Lock()
TOOLS = None
MIXIN = [46,47,18,2,53,8,23,32,15,50,10,31,58,3,45,35,27,43,5,49,33,9,42,19,29,28,14,39,12,38,41,13,37,48,7,16,24,55,40,61,26,17,0,1,60,51,30,4,22,25,54,21,56,59,6,63,57,62,11,36,20,34,44,52]
QUALITY = {16:'360P',32:'480P',64:'720P',74:'720P60',80:'1080P',112:'1080P 高码率',116:'1080P60',120:'4K',125:'HDR',126:'杜比视界',127:'8K'}

def video_url(raw):
    m = re.search(r'https://[^\s<>]+', str(raw))
    if not m:
        raise ValueError('请输入 B站视频链接')
    u = urllib.parse.urlsplit(m[0])
    if u.hostname not in ('www.bilibili.com', 'm.bilibili.com', 'bilibili.com') or u.username or u.password or u.port:
        raise ValueError('请使用 B站单个视频的 HTTPS 播放页链接')
    if not re.fullmatch(r'/video/(BV\w+|av\d+)/?', u.path, re.I):
        raise ValueError('暂支持 B站 BV / av 视频链接')
    p = urllib.parse.parse_qs(u.query).get('p', ['1'])[0]
    if not p.isdigit() or not 1 <= int(p) <= 1000:
        raise ValueError('分P参数无效')
    return 'https://www.bilibili.com' + u.path.rstrip('/') + '/?p=' + p

def protect(data, decrypt=False):
    if os.name != 'nt':
        raise RuntimeError('此助手使用 Windows 本机加密，请在 Windows 运行')
    class BLOB(ctypes.Structure):
        _fields_ = [('size', ctypes.c_ulong), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    buf = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    incoming, outgoing = BLOB(len(data), buf), BLOB()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    if decrypt:
        ok = crypt.CryptUnprotectData(ctypes.byref(incoming), None, None, None, None, 1, ctypes.byref(outgoing))
    else:
        ok = crypt.CryptProtectData(ctypes.byref(incoming), ctypes.c_wchar_p('CreativeHubHQ'), None, None, None, 1, ctypes.byref(outgoing))
    if not ok:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(outgoing.data, outgoing.size)
    finally:
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree(outgoing.data)

def load_cookies():
    path = STATE / 'session.dat'
    if not path.exists():
        return {}
    try:
        return json.loads(protect(path.read_bytes(), True))
    except Exception:
        return {}

def bili_json(url, cookies=None, opener=None):
    headers = {'User-Agent': UA, 'Referer': 'https://www.bilibili.com/'}
    if cookies:
        headers['Cookie'] = '; '.join(k + '=' + v for k, v in cookies.items() if k in COOKIE_NAMES and not re.search(r'[\r\n;]', v))
    request = urllib.request.Request(url, headers=headers)
    open_url = opener.open if opener else urllib.request.urlopen
    with open_url(request, timeout=25) as response:
        return json.loads(response.read(2000000))

def account(cookies=None):
    cookies = cookies if cookies is not None else load_cookies()
    if not cookies:
        return {'logged_in': False, 'message': '尚未登录'}
    d = bili_json('https://api.bilibili.com/x/web-interface/nav', cookies)
    if d.get('code') != 0 or not d.get('data', {}).get('isLogin'):
        return {'logged_in': False, 'message': '登录已失效，请重新扫码'}
    d = d['data']
    return {'logged_in': True, 'username': d.get('uname', ''), 'vip': (d.get('vipStatus', d.get('vip', {}).get('status', 0)) == 1)}

@contextlib.contextmanager
def cookie_file():
    cookies = load_cookies()
    if not cookies:
        yield None
        return
    STATE.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='session-', suffix='.txt', dir=STATE)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write('# Netscape HTTP Cookie File\n')
            for k, v in cookies.items():
                if k in COOKIE_NAMES and not re.search(r'[\r\n\t]', v):
                    f.write('.bilibili.com\tTRUE\t/\tTRUE\t0\t' + k + '\t' + v + '\n')
        yield name
    finally:
        Path(name).unlink(missing_ok=True)

def tool_args(cookie=None):
    args = [str(TOOLS / 'yt-dlp.exe'), '--no-playlist', '--no-warnings', '--referer', 'https://www.bilibili.com/', '--socket-timeout', '25', '--retries', '2']
    if cookie:
        args += ['--cookies', cookie]
    return args

def media_url(raw):
    u = urllib.parse.urlsplit(raw)
    domains = ('bilivideo.com', 'bilivideo.cn', 'edge.mountaintoys.cn', 'hdslb.com')
    allowed = any(u.hostname == d or (u.hostname or '').endswith('.' + d) for d in domains)
    if u.scheme != 'https' or not allowed or u.username or u.password or (u.port and not ((u.port == 4483 and (u.hostname or '').endswith('.edge.mountaintoys.cn')) or (u.port in (4483, 8082) and (u.hostname or '').endswith('.mcdn.bilivideo.cn')))):
        raise ValueError('来源没有返回可信的 B站媒体地址')
    return raw

def api_metadata(url):
    cookies = load_cookies()
    ident = urllib.parse.urlsplit(url).path.split('/')[2]
    params = {'aid': ident[2:]} if ident.lower().startswith('av') else {'bvid': ident}
    info = bili_json('https://api.bilibili.com/x/web-interface/view?' + urllib.parse.urlencode(params), cookies)
    if info.get('code') != 0:
        raise ValueError('无法读取此视频')
    info = info['data']
    index = int(urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)['p'][0]) - 1
    part = info.get('pages', [])[index]
    nav = bili_json('https://api.bilibili.com/x/web-interface/nav', cookies)
    images = nav['data']['wbi_img']
    key_raw = ''.join(urllib.parse.urlsplit(images[k]).path.rsplit('/', 1)[-1].split('.')[0] for k in ('img_url', 'sub_url'))
    key = ''.join(key_raw[i] for i in MIXIN)[:32]
    params = {'bvid': info['bvid'], 'cid': part['cid'], 'qn':120, 'fnval':4048, 'fourk':1, 'wts':round(time.time())}
    query = urllib.parse.urlencode(sorted(params.items()))
    query += '&w_rid=' + hashlib.md5((query + key).encode()).hexdigest()
    play = bili_json('https://api.bilibili.com/x/player/wbi/playurl?' + query, cookies)
    if play.get('code') != 0:
        raise ValueError('B站未返回账号可用画质')
    dash = play['data'].get('dash') or {}
    audios = [a for a in dash.get('audio', []) if a.get('baseUrl') or a.get('base_url')]
    audio = max(audios, key=lambda a: a.get('bandwidth', 0), default=None)
    formats, streams = [], {}
    if audio:
        audio_url = media_url(audio.get('baseUrl') or audio.get('base_url'))
        for f in dash.get('video', []):
            try:
                raw = media_url(f.get('baseUrl') or f.get('base_url'))
            except (ValueError, TypeError):
                continue
            fid = str(f.get('id')) + '-' + str(len(formats))
            formats.append({'format_id':fid, 'quality':f.get('id'), 'height':f.get('height'), 'width':f.get('width'), 'fps':float(f.get('frameRate') or f.get('frame_rate') or 0), 'tbr':f.get('bandwidth', 0), 'vcodec':f.get('codecs'), 'acodec':'none'})
            streams[fid] = {'video':raw, 'audio':audio_url}
    return {'title':info['title'] + (' · ' + part.get('part', '') if len(info.get('pages', [])) > 1 else ''), 'formats':formats}, streams

def fetch_track(url, filename, job, start, weight):
    class Redirects(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, msg, headers, newurl):
            media_url(newurl)
            return super().redirect_request(request, fp, code, msg, headers, newurl)
    opener = urllib.request.build_opener(Redirects())
    request = urllib.request.Request(media_url(url), headers={'User-Agent':UA, 'Referer':'https://www.bilibili.com/'})
    with opener.open(request, timeout=30) as response, filename.open('wb') as f:
        total = int(response.headers.get('Content-Length', 0))
        received = 0
        while block := response.read(1024 * 1024):
            if job.get('cancelled'):
                raise ValueError('已停止')
            if received == 0 and block[4:8] != b'ftyp':
                raise ValueError('没有收到有效的 MP4 媒体轨')
            received += len(block)
            f.write(block)
            if total:
                job['percent'] = min(99, start + weight * received / total)
        if not received or (total and total != received):
            raise ValueError('下载文件不完整，请重试')

def rows(info):
    groups = {}
    for f in info.get('formats', []):
        height = int(f.get('height') or 0)
        fid = str(f.get('format_id') or '')
        if height <= 0 or f.get('vcodec') in (None, 'none') or not re.fullmatch(r'[\w.-]{1,80}', fid):
            continue
        # Choose a browser-friendly codec within each actual resolution, without a 1080P cap.
        score = (str(f.get('vcodec', '')).startswith('avc1'), float(f.get('fps') or 0), float(f.get('tbr') or 0))
        group = (int(f.get('quality') or 0), height)
        if group not in groups or score > groups[group][0]:
            groups[group] = (score, {'id': fid, 'height': height, 'width': f.get('width'), 'fps': f.get('fps'), 'codec': f.get('vcodec'), 'has_audio': f.get('acodec') not in (None, 'none'), 'label': QUALITY.get(group[0], '8K' if height >= 4320 else '4K' if height >= 2160 else str(height) + 'P')})
    return [groups[h][1] for h in sorted(groups, reverse=True)]

def analyze(raw):
    url = video_url(raw)
    streams = {}
    try:
        info, streams = api_metadata(url)
        if not info['formats']:
            raise ValueError('直接接口没有返回可用媒体轨')
    except Exception:
        with cookie_file() as cookie:
            process = subprocess.run(tool_args(cookie) + ['--skip-download', '--dump-single-json', url], capture_output=True, timeout=120, encoding='utf-8', errors='replace', creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if process.returncode:
            raise ValueError('B站解析失败，请确认登录状态、视频权限或稍后重试。')
        info = json.loads(process.stdout)
    formats = rows(info)
    if not formats:
        raise ValueError('没有返回可下载的画质')
    ident = secrets.token_urlsafe(24)
    result = {'id': ident, 'title': info.get('title', '视频'), 'formats': formats, 'account': account()}
    with LOCK:
        for old, saved in list(ANALYSES.items()):
            if time.time() - saved['time'] > 1800:
                ANALYSES.pop(old, None)
        ANALYSES[ident] = {'url': url, 'result': result, 'time': time.time(), 'streams':streams}
    return result

def download_job(ident, analysis, selected):
    job = JOBS[ident]
    work = STATE / 'downloads' / ident
    work.mkdir(parents=True, exist_ok=True)
    try:
        direct = analysis.get('streams', {}).get(selected['id'])
        if direct:
            fetch_track(direct['video'], work / 'video.m4s', job, 0, 75)
            fetch_track(direct['audio'], work / 'audio.m4s', job, 75, 15)
            job['stage'] = '正在合并画面与声音'
            process = subprocess.Popen([str(TOOLS / 'ffmpeg.exe'), '-y', '-i', str(work / 'video.m4s'), '-i', str(work / 'audio.m4s'), '-c', 'copy', '-movflags', '+faststart', str(work / 'video.mp4')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            job['process'] = process
            if job.get('cancelled'):
                process.terminate()
            code = process.wait()
        else:
          with cookie_file() as cookie:
            fmt = selected['id'] if selected['has_audio'] else selected['id'] + '+bestaudio[ext=m4a]/' + selected['id'] + '+bestaudio'
            args = tool_args(cookie) + ['--format', fmt, '--ffmpeg-location', str(TOOLS), '--merge-output-format', 'mp4', '--newline', '--progress-template', 'download:HQ_PROGRESS:%(progress._percent_str)s', '--output', str(work / 'video.%(ext)s'), analysis['url']]
            process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf-8', errors='replace', creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            job['process'] = process
            if job.get('cancelled'):
                process.terminate()
            for line in process.stdout:
                if 'HQ_PROGRESS:' in line:
                    percent = re.search(r'(\d+(?:\.\d+)?)%', line)
                    if percent:
                        job['percent'] = min(99, float(percent.group(1)))
                if '[Merger]' in line:
                    job['stage'] = '正在合并画面与声音'
            code = process.wait()
        if job.get('cancelled'):
            job.update(status='cancelled', stage='已停止')
            return
        output = work / 'video.mp4'
        if code != 0 or not output.exists():
            raise ValueError('下载未完成，请重新检查画质与登录权限。')
        job.update(status='done', percent=100, stage='下载和合并完成', path=output)
    except Exception as e:
        job.update(status='cancelled' if job.get('cancelled') else 'error', stage='已停止' if job.get('cancelled') else '下载未完成，请重新解析或检查网络和账号权限。')
    finally:
        job.pop('process', None)

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def reply(self, data, status=200):
        content = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(content)

    def allowed(self, mutate=False):
        if self.headers.get('Host') not in (f'127.0.0.1:{PORT}', f'localhost:{PORT}'):
            self.reply({'error': '本机访问地址无效'}, 403)
            return False
        if mutate and self.headers.get('Origin') not in (f'http://127.0.0.1:{PORT}', f'http://localhost:{PORT}'):
            self.reply({'error': '请在本地助手页面操作'}, 403)
            return False
        return True

    def do_GET(self):
        if not self.allowed():
            return
        u = urllib.parse.urlsplit(self.path)
        try:
            if u.path == '/api/account':
                return self.reply(account())
            if u.path == '/api/job':
                ident = urllib.parse.parse_qs(u.query).get('id', [''])[0]
                job = JOBS.get(ident)
                if not job:
                    return self.reply({'error': '任务不存在'}, 404)
                return self.reply({k: v for k, v in job.items() if k in ('status', 'percent', 'stage', 'label')})
            if u.path == '/api/file':
                job = JOBS.get(urllib.parse.parse_qs(u.query).get('id', [''])[0], {})
                if job.get('status') != 'done':
                    return self.reply({'error': '文件尚未完成'}, 404)
                filename = 'Bilibili_' + job['label'] + '.mp4'
                self.send_response(200)
                self.send_header('Content-Type', 'video/mp4')
                self.send_header('Content-Length', str(job['path'].stat().st_size))
                self.send_header('Content-Disposition', 'attachment; filename="' + filename + '"')
                self.end_headers()
                with job['path'].open('rb') as f:
                    while chunk := f.read(1024 * 1024):
                        self.wfile.write(chunk)
                return
            files = {'/': ('index.html', 'text/html; charset=utf-8'), '/app.js': ('app.js', 'text/javascript'), '/qrcode.min.js': ('qrcode.min.js', 'text/javascript')}
            if u.path not in files:
                return self.reply({'error': '页面不存在'}, 404)
            name, mime = files[u.path]
            content = (ROOT / name).read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            self.reply({'error': str(e)[:200]}, 422)

    def do_POST(self):
        if not self.allowed(True):
            return
        try:
            n = int(self.headers.get('Content-Length', 0))
            if n < 0 or n > 8192:
                return self.reply({'error': '请求过长'}, 413)
            data = json.loads(self.rfile.read(n) or '{}')
            if self.path == '/api/login/qr':
                jar = http.cookiejar.CookieJar()
                opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
                response = bili_json('https://passport.bilibili.com/x/passport-login/web/qrcode/generate', opener=opener)
                if response.get('code') != 0:
                    raise ValueError('B站暂时无法生成二维码')
                qr_url = urllib.parse.urlsplit(response['data']['url'])
                if qr_url.scheme != 'https' or qr_url.hostname not in ('passport.bilibili.com', 'account.bilibili.com') or qr_url.username or qr_url.password or qr_url.port:
                    raise ValueError('B站未返回有效的官方登录二维码')
                ident = secrets.token_urlsafe(24)
                QR.clear()
                QR[ident] = {'key': response['data']['qrcode_key'], 'opener': opener, 'jar': jar, 'time': time.time()}
                return self.reply({'id': ident, 'url': response['data']['url']})
            if self.path == '/api/login/poll':
                session = QR.get(data.get('id'))
                if not session or time.time() - session['time'] > 180:
                    raise ValueError('二维码已过期，请重新生成')
                result = bili_json('https://passport.bilibili.com/x/passport-login/web/qrcode/poll?' + urllib.parse.urlencode({'qrcode_key': session['key']}), opener=session['opener'])
                if result.get('code') != 0:
                    raise ValueError('B站登录验证未成功')
                state = result['data']['code']
                if state == 0:
                    cookies = {c.name: c.value for c in session['jar'] if c.name in COOKIE_NAMES}
                    url_cookies = urllib.parse.parse_qs(urllib.parse.urlsplit(result['data'].get('url', '')).query)
                    for k in COOKIE_NAMES:
                        if k not in cookies and k in url_cookies:
                            cookies[k] = url_cookies[k][0]
                    verified = account(cookies)
                    if not verified['logged_in']:
                        raise ValueError('扫码完成但账号验证失败，请重试')
                    STATE.mkdir(parents=True, exist_ok=True)
                    (STATE / 'session.dat').write_bytes(protect(json.dumps(cookies).encode()))
                    QR.pop(data.get('id'), None)
                    return self.reply({'state': 0, 'account': verified})
                return self.reply({'state': state})
            if self.path == '/api/logout':
                (STATE / 'session.dat').unlink(missing_ok=True)
                return self.reply({'logged_in': False})
            if self.path == '/api/analyze':
                return self.reply(analyze(data.get('url', '')))
            if self.path == '/api/download':
                analysis = ANALYSES.get(data.get('analysis'))
                if not analysis or time.time() - analysis['time'] > 1800:
                    raise ValueError('解析已过期，请重新检查画质')
                selected = next((f for f in analysis['result']['formats'] if f['id'] == data.get('format')), None)
                if not selected:
                    raise ValueError('此画质尚未验证可用')
                if any(j['status'] == 'running' for j in JOBS.values()):
                    raise ValueError('请等待当前下载完成')
                ident = secrets.token_urlsafe(20)
                JOBS[ident] = {'status': 'running', 'percent': 0, 'stage': '正在下载画面和声音', 'label': selected['label']}
                threading.Thread(target=download_job, args=(ident, analysis, selected), daemon=True).start()
                return self.reply({'id': ident})
            if self.path == '/api/cancel':
                job = JOBS.get(data.get('id'))
                if job:
                    job['cancelled'] = True
                    if job.get('process'):
                        job['process'].terminate()
                return self.reply({'ok': True})
            return self.reply({'error': '接口不存在'}, 404)
        except Exception as e:
            self.reply({'error': str(e)[:200]}, 422)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--tools', required=True)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    TOOLS = Path(args.tools).resolve()
    if not all((TOOLS / f).is_file() for f in ('yt-dlp.exe', 'ffmpeg.exe')):
        raise SystemExit('请将高清助手解压到 Windows 完整版旁，并保留 tools 文件夹。')
    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    print(f'高清助手 http://127.0.0.1:{PORT}/', flush=True)
    if not args.no_browser:
        webbrowser.open(f'http://127.0.0.1:{PORT}/')
    server.serve_forever()
