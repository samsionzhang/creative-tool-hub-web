param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$pythonCandidates = @((Join-Path $PSScriptRoot 'runtime\python.exe'))
$pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
if ($pythonCommand) { $pythonCandidates += $pythonCommand.Source }
$pythonCandidates += (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
$pythonCandidates += (Join-Path $env:USERPROFILE 'AppData\Local\Programs\Python\Python313\python.exe')
$pythonCandidates += (Join-Path $env:USERPROFILE 'AppData\Local\Programs\Python\Python312\python.exe')
$hqPython = $null
foreach ($candidate in $pythonCandidates) {
 if ((Test-Path -LiteralPath $candidate) -and ($candidate -notmatch '\\WindowsApps\\')) {
  try {
   $probe = Start-Process -FilePath $candidate -ArgumentList @('-c', '"import sys; assert sys.version_info >= (3,10)"') -WindowStyle Hidden -PassThru
   if (!$probe.WaitForExit(10000)) { $probe.Kill(); continue }
   if ($probe.ExitCode -eq 0) { $hqPython = $candidate; break }
  } catch { continue }
 }
}
if (!$hqPython) { throw 'Python 3.10+ is required. Install Python, then run Start-HQ.cmd again.' }
$hqTools = $null
$candidateDirs = @((Join-Path $PSScriptRoot 'tools'), (Join-Path $PSScriptRoot '..\tools'), (Join-Path $PSScriptRoot '..\..\tools'), (Join-Path $PSScriptRoot '..\collector\tools'))
foreach ($candidate in $candidateDirs) { if ((Test-Path (Join-Path $candidate 'yt-dlp.exe')) -and (Test-Path (Join-Path $candidate 'ffmpeg.exe'))) { $hqTools = (Resolve-Path $candidate).Path; break } }
if (!$hqTools) { throw 'Extract this HQ assistant beside the Windows full edition tools folder (yt-dlp.exe and ffmpeg.exe).' }
if ($CheckOnly) { Write-Output "Ready: $hqPython | $hqTools"; exit 0 }
& $hqPython (Join-Path $PSScriptRoot 'server.py') --tools $hqTools
