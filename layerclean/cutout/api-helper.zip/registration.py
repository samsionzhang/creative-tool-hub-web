"""Local-only geometric registration. Never send inputs to a network service."""
import base64, io
import cv2
import numpy as np
from PIL import Image

def validate_critical(src, output, regions):
    if not isinstance(regions,list) or not 1<=len(regions)<=100:
        raise ValueError('缺少原图关键部位保护区')
    checked=0
    for region in regions:
        if region.get('kind')=='erase':continue
        points=region.get('points')
        if region.get('kind') not in ('face','hand') or not isinstance(points,list) or not 3<=len(points)<=500:
            raise ValueError('保护区格式无效')
        p=np.asarray(points,dtype=np.float32)
        if p.shape!=(len(points),2) or not np.all(np.isfinite(p)) or np.any(p<0) or np.any(p>1):
            raise ValueError('保护区坐标无效')
        mask=np.zeros(src.shape[:2],np.uint8)
        cv2.fillPoly(mask,[np.round(p*[src.shape[1]-1,src.shape[0]-1]).astype(np.int32)],255)
        inner=cv2.erode(mask,np.ones((3,3),np.uint8))>0
        if inner.sum()<16:raise ValueError('保护区太小，请完整圈选关键部位')
        error=np.mean(np.abs(src[:,:,:3].astype(np.float32)-output[:,:,:3].astype(np.float32)),axis=2)[inner]
        missing=np.mean(output[:,:,3][inner]<220)
        if float(error.mean())>28 or float(np.mean(error>35))>.25 or missing>.1:
            label='脸部' if region['kind']=='face' else '手部'
            raise ValueError(label+'与原图变化过大，可能产生重复轮廓或拼接错误；已拒绝合成。请更换 AI 结果，或使用保留原图的本地分割。')
        checked+=1
    if not checked:raise ValueError('缺少脸或手的保护区')
    return checked

def decode(encoded):
    if not isinstance(encoded,str) or len(encoded)>24000000:
        raise ValueError('图片数据过大')
    raw=base64.b64decode(encoded,validate=True)
    with Image.open(io.BytesIO(raw)) as im:
        if im.width*im.height>16000000 or max(im.size)>8192:
            raise ValueError('对齐图片超过尺寸限制')
        return np.array(im.convert('RGBA'))

def register(payload):
    src,candidate=decode(payload.get('source')),decode(payload.get('candidate'))
    a=candidate[:,:,3]
    if np.mean(a<10)<.01 or np.mean(a>200)<.01:
        raise ValueError('AI 结果必须有真实透明背景；未对不透明图片强行抠图')
    def features(im):
        scale=min(1,1600/max(im.shape[:2]))
        small=cv2.resize(im,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        gray=cv2.cvtColor(small[:,:,:3],cv2.COLOR_RGB2GRAY)
        keys,desc=cv2.SIFT_create(nfeatures=8000).detectAndCompute(gray,(small[:,:,3]>240).astype('uint8')*255)
        return keys,desc,scale
    ka,da,sa=features(candidate);kb,db,sb=features(src)
    if da is None or db is None or min(len(da),len(db))<24:
        raise ValueError('可匹配细节不足，无法可靠对齐；已停止')
    matches=cv2.BFMatcher().knnMatch(da,db,k=2)
    good=[pair[0] for pair in matches if len(pair)==2 and pair[0].distance<.7*pair[1].distance]
    if len(good)<24:raise ValueError('AI 改动过大，原图匹配点不足；已停止')
    p=np.float32([ka[m.queryIdx].pt for m in good])/sa
    q=np.float32([kb[m.trainIdx].pt for m in good])/sb
    matrix,inside=cv2.estimateAffinePartial2D(p,q,method=cv2.RANSAC,ransacReprojThreshold=3/sb,maxIters=10000,confidence=.999)
    if matrix is None:raise ValueError('AI 与原图无法对齐；已停止')
    inside=inside.ravel().astype(bool);count=int(inside.sum())
    error=np.linalg.norm(cv2.transform(p[None],matrix)[0]-q,axis=1)[inside]*sb
    scale=float(np.hypot(matrix[0,0],matrix[0,1]))
    normalized=scale*max(candidate.shape[:2])/max(src.shape[:2])
    angle=abs(float(np.degrees(np.arctan2(matrix[1,0],matrix[0,0]))))
    # Require distributed evidence, not a few coincidental matches in one eye.
    spread=np.ptp(q[inside],axis=0) if count else np.zeros(2)
    if count<24 or count/len(good)<.25 or np.median(error)>2.5 or not .4<normalized<2.5 or angle>12 or spread[0]<src.shape[1]*.12 or spread[1]<src.shape[0]*.2:
        raise ValueError('AI 人物变化或错位过大，未通过对齐检查；请换用其它结果')
    premult=candidate.astype(np.float32)/255
    premult[:,:,:3]*=premult[:,:,3:4]
    warped=cv2.warpAffine(premult,matrix,(src.shape[1],src.shape[0]),flags=cv2.INTER_LINEAR)
    warped[:,:,:3]/=np.maximum(warped[:,:,3:4],1/255)
    warped[warped[:,:,3]<8/255]=0
    output=np.clip(np.round(warped*255),0,255).astype('uint8')
    checked=validate_critical(src,output,payload.get('regions'))
    b=io.BytesIO();Image.fromarray(output).save(b,format='PNG')
    return {'image':base64.b64encode(b.getvalue()).decode(),'width':src.shape[1],'height':src.shape[0],
            'inliers':count,'median_error':round(float(np.median(error)),2),'checked_regions':checked}
