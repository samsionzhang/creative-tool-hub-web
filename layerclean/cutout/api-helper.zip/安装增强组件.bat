@echo off
cd /d "%~dp0"
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" (
  "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -m pip install --target .deps -r requirements-ai.txt
  goto done
)
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -m pip install --target .deps -r requirements-ai.txt
) else (
  python -m pip install --target .deps -r requirements-ai.txt
)
:done
pause
