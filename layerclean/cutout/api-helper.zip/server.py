"""Loopback-only personal image API helper. No credentials or images are saved."""
import http.server, urllib.request, urllib.error, urllib.parse, json, webbrowser
from pathlib import Path
import mimetypes
import sys, threading
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'.deps'))
register_lock=threading.Lock()
LOCAL=HERE/'web'
if not LOCAL.is_dir(): LOCAL=HERE.parent.parent/'dist'
SITE = 'https://senxuan-creative-hub.senxuanq.chatgpt.site'
ORIGIN = 'http://127.0.0.1:8897'
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def send(self, status, body, content_type='application/json'):
        self.send_response(status); self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
    def valid_host(self): return self.headers.get('Host') == '127.0.0.1:8897'
    def do_GET(self):
        if not self.valid_host(): return self.send(403,b'{}')
        path=urllib.parse.urlsplit(self.path).path
        if path=='/api/cutout-capabilities':
            try:
                import registration, auto_regions, mediapipe
                return self.send(200,b'{"registration":true,"auto_regions":true}')
            except ImportError:
                return self.send(503,json.dumps({'error':'请运行安装增强组件.bat，完成后重启本地助手'}).encode())
        if path=='/':
            self.send_response(302); self.send_header('Location','/layerclean/cutout/'); self.end_headers(); return
        if not path.startswith(('/layerclean/cutout/','/collector/zip.js')) or '..' in path: return self.send(404,b'{}')
        local=(LOCAL/path.lstrip('/')).resolve()
        if local.is_relative_to(LOCAL.resolve()):
            if local.is_dir(): local=local/'index.html'
            if local.is_file(): return self.send(200,local.read_bytes(),mimetypes.guess_type(str(local))[0] or 'application/octet-stream')
        try:
            with urllib.request.urlopen(SITE+path,timeout=90) as r:
                self.send(r.status,r.read(),r.headers.get('Content-Type','application/octet-stream'))
        except Exception: self.send(502,b'{"error":"Could not load tool assets"}')
    def do_POST(self):
        if self.path in ('/api/register-cutout','/api/detect-regions'):
            if not self.valid_host() or self.headers.get('Origin')!=ORIGIN:return self.send(403,b'{}')
            if not register_lock.acquire(blocking=False):return self.send(429,b'{"error":"Local alignment is busy"}')
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<50000000:return self.send(413,b'{}')
                from registration import register
                payload=json.loads(self.rfile.read(size))
                if self.path=='/api/detect-regions':
                    from auto_regions import detect_regions
                    result=detect_regions(payload.get('source'))
                else:result=register(payload)
                self.send(200,json.dumps(result).encode())
            except ImportError:self.send(503,json.dumps({'error':'请运行安装增强组件.bat，完成后重启本地助手'}).encode())
            except ValueError as e:self.send(422,json.dumps({'error':str(e)}).encode())
            except Exception:self.send(500,json.dumps({'error':'本地对齐失败，未返回处理结果'}).encode())
            finally:register_lock.release()
            return
        if not self.valid_host() or self.path!='/api/image-edit' or self.headers.get('Origin')!=ORIGIN: return self.send(403,b'{}')
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<12000000: return self.send(413,b'{}')
            endpoint=self.headers.get('X-Image-Endpoint','')
            url=urllib.parse.urlsplit(endpoint)
            if url.scheme!='https' or not url.hostname or url.username or url.password or url.query or url.fragment: return self.send(400,b'{}')
            headers={'Authorization':self.headers.get('Authorization',''),'Content-Type':self.headers.get('Content-Type','')}
            class NoRedirect(urllib.request.HTTPRedirectHandler):
                def redirect_request(self,*args,**kwargs): return None
            req=urllib.request.Request(endpoint,data=self.rfile.read(length),headers=headers)
            with urllib.request.build_opener(NoRedirect).open(req,timeout=600) as r:
                body=r.read(90000001)
                if len(body)>90000000: return self.send(502,b'{}')
                self.send(r.status,body)
        except urllib.error.HTTPError as e: self.send(e.code,json.dumps({'error':'Provider rejected request','status':e.code}).encode())
        except Exception: self.send(502,b'{"error":"Provider connection failed"}')
if __name__=='__main__':
    server=http.server.ThreadingHTTPServer(('127.0.0.1',8897),Handler)
    print('Personal image helper: '+ORIGIN+'/layerclean/cutout/')
    print('Keep this window open. Press Ctrl+C to stop. Saved API settings stay in your browser.')
    if '--no-browser' not in sys.argv:webbrowser.open(ORIGIN+'/layerclean/cutout/')
    try: server.serve_forever()
    except KeyboardInterrupt: server.server_close()
