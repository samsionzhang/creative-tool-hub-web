"""Detect critical anatomy locally; downloaded models never receive user images."""
from pathlib import Path
import hashlib, urllib.request
import cv2, numpy as np
from registration import decode
MODELS={
 'face_landmarker':'64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff',
 'hand_landmarker':'fbc2a30080c3c557093b5ddfc334698132eb341044ccee322ccf8bcf3607cde1'}
def model_path(name):
 path=Path(__file__).parent/'.models'/(name+'.task')
 if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==MODELS[name]:return str(path)
 path.parent.mkdir(exist_ok=True)
 url=f'https://storage.googleapis.com/mediapipe-models/{name}/{name}/float16/latest/{name}.task'
 with urllib.request.urlopen(url,timeout=90) as response:data=response.read(16000000)
 if hashlib.sha256(data).hexdigest()!=MODELS[name]:raise ValueError('识别模型校验失败，未调用图像 API')
 path.write_bytes(data);return str(path)
def select_anatomy(found,w,h):
 faces=[r for r in found if r['kind']=='face'];hands=[r for r in found if r['kind']=='hand'];selected=[]
 for face in faces:
  points=np.array(face['points']);height=np.ptp(points[:,1])*h
  nearby=[hand for hand in hands if np.linalg.norm((np.array(hand['center'])-face['center'])*[w,h])<8*height]
  nearby.sort(key=lambda hand:np.linalg.norm((np.array(hand['center'])-face['center'])*[w,h]))
  if len(nearby)<2:raise ValueError('未可靠识别完整的脸和双手，已停止 AI 调用；遮挡或过小的手暂不能自动保护，可使用本地分割')
  selected.append(face)
  for hand in nearby[:2]:
   if hand not in selected:selected.append(hand)
 if not faces:raise ValueError('未可靠识别人脸，已停止 AI 调用；可使用本地分割')
 return [{'kind':r['kind'],'points':r['points']} for r in selected]
def detect_regions(encoded):
 import mediapipe as mp
 a=decode(encoded)[:,:,:3];h,w=a.shape[:2];a=np.ascontiguousarray(a)
 if max(w,h)>2048:raise ValueError('自动识别输入尺寸过大')
 vision=mp.tasks.vision;found=[]
 specs=[('face',vision.FaceLandmarker,vision.FaceLandmarkerOptions,'face_landmarker','face_landmarks'),('hand',vision.HandLandmarker,vision.HandLandmarkerOptions,'hand_landmarker','hand_landmarks')]
 for kind,cls,opt,model,field in specs:
  kwargs={'num_faces':4} if kind=='face' else {'num_hands':4}
  with cls.create_from_options(opt(base_options=mp.tasks.BaseOptions(model_asset_path=model_path(model)),**kwargs)) as task:
   crops=[(0,0,w,h)]+[(x,y,min(w,x+512),min(h,y+512)) for y in range(0,max(1,h-200),320) for x in range(0,max(1,w-200),320)]
   if kind=='hand':crops += [(x,y,min(w,x+384),min(h,y+384)) for y in range(0,max(1,h-150),192) for x in range(0,max(1,w-150),192)]
   for x,y,r,b in crops:
    result=task.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=np.ascontiguousarray(a[y:b,x:r])))
    for landmarks in getattr(result,field):
     pts=np.array([[(p.x*(r-x)+x)/w,(p.y*(b-y)+y)/h] for p in landmarks],np.float32)
     if np.any(pts<0) or np.any(pts>1):continue
     center=pts.mean(axis=0)
     if any(k['kind']==kind and np.linalg.norm(center-np.array(k['center']))<.04 for k in found):continue
     hull=cv2.convexHull(pts).reshape(-1,2);found.append({'kind':kind,'points':hull.tolist(),'center':center.tolist()})
 regions=select_anatomy(found,w,h)
 return {'regions':regions,'faces':sum(r['kind']=='face' for r in regions),'hands':sum(r['kind']=='hand' for r in regions),'width':w,'height':h}
